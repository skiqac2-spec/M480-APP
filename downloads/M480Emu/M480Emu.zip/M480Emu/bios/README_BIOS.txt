﻿본인 소유 기기에서 추출한 BIOS 파일을 이 폴더에 넣으면 자동으로 사용됩니다. 없어도 실행됩니다.
PS1: scph1001.bin 등 / GBA: gba_bios.bin
